﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace _1WeekAppliedProject
{
    public partial class Main : System.Web.UI.Page
    {
        string con = "Data Source=dixithg\\dixithsql;Initial Catalog=week1AP;Integrated Security=True";
        string EmailVar,FnameVar,LnameVar,AgeVar,Gendervar,commuteVar;

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("SignUp.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConn = new SqlConnection(con))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"SELECT Email, Password, Fname, Lname, Age, Gender, Commute FROM Reg1 WHERE Email = @idParam";
                    cmd.Parameters.Add("@idParam", SqlDbType.VarChar).Value = TextBox1.Text.ToString(); 
                    cmd.Connection = sqlConn;
                    sqlConn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Label1.Text = (string)reader[1];
                            EmailVar = (string)reader[0];
                            FnameVar = (string)reader[2];
                            LnameVar = (string)reader[3];
                            AgeVar = (string)reader[4];
                            Gendervar = (string)reader[5];
                            commuteVar = (string)reader[6];
                        }
                    }
                    if (Label1.Text == TextBox2.Text.ToString() && EmailVar == TextBox1.Text.ToString())
                    {
                        //  Label1.Text = "yehhhhh";
                        Session["EmailS"] = TextBox1.Text;
                        Session["LastNames"] = LnameVar;
                        Session["FirstNames"] = FnameVar;
                        Session["AgeS"] = AgeVar;
                        Session["GenderS"] = Gendervar;
                        Session["CommuteS"] = commuteVar;

                        Response.Redirect("Welcome.aspx");
                    }
                    else
                    {
                        Label1.Text = "Incorrect Email or Password";
                    }
                }
            }


            /*
            SqlConnection sqlCon = new SqlConnection(con);
            sqlCon.Open();
            if (sqlCon.State == System.Data.ConnectionState.Open)
            {
                string insert_com = "select Email,Password from Reg where Fname='"+TextBox1.Text.ToString()+"'";
                SqlCommand execm = new SqlCommand(insert_com, sqlCon);
                SqlDataReader reader = execm.ExecuteReader();

                // Call Read before accessing data.
                while (reader.Read())
                {
                    ReadSingleRow((IDataRecord)reader);
                }

                // Call Close when done reading.
                reader.Close();

            }
            */
        }
        public String CurrentCity
        {
            get
            {
                return TextBox1.Text;
            }
        }

    }
}