﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace _1WeekAppliedProject
{
    public partial class SignUp : System.Web.UI.Page
    {
       string con = "Data Source=dixithg\\dixithsql;Initial Catalog=week1AP;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_reg_Click(object sender, EventArgs e)
        {
            
            SqlConnection sqlCon = new SqlConnection(con);
            sqlCon.Open();
            if (sqlCon.State == System.Data.ConnectionState.Open)
            {
                string day = DropDownList2.Text.ToString();
                string mnth = DropDownList3.Text.ToString();
                string year = DropDownList4.Text.ToString();
                string gender = DropDownList5.Text.ToString();
                string Commute = DropDownList1.Text.ToString();
                string dateFormate = mnth + "-" + day + "-" + year;
                
                string insert_com = "insert into Reg1(fname,Lname,Email,Password,Age,Gender,Commute)values('"+TextBox1.Text.ToString()+"','"+TextBox2.Text.ToString()+ "','" + TextBox3.Text.ToString() + "','" + TextBox4.Text.ToString() + "','" + dateFormate + "','" + gender + "','" + Commute + "')";
                SqlCommand execm = new SqlCommand(insert_com,sqlCon);
                execm.ExecuteNonQuery();
                Label1.ForeColor = System.Drawing.Color.RoyalBlue;
                Label1.Text = "Registration Successfull";
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Text = "Connot Connect to database!!";
            }
            
            
           
        }
    }
}