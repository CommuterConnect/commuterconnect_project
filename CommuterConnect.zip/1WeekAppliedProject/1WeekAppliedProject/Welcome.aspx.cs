﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace _1WeekAppliedProject
{
    public partial class Welcome : System.Web.UI.Page
    {
        string con = "Data Source=dixithg\\dixithsql;Initial Catalog=week1AP;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            string Email = Session["EmailS"].ToString();
            Label2.Text = Email;
            string firstname = Session["FirstNames"].ToString();
            string Lname = Session["LastNames"].ToString();
            Label1.Text = firstname + Lname;
            string Age = Session["AgeS"].ToString();
            Label3.Text = Age;
            string gender = Session["GenderS"].ToString();
            Label4.Text = gender;
            string Commute = Session["CommuteS"].ToString();
            Label5.Text = Commute;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConn = new SqlConnection(con))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"SELECT Email, Password, Fname, Lname, Age, Gender, Commute FROM Reg1 WHERE Fname = @idParam";
                    cmd.Parameters.Add("@idParam", SqlDbType.VarChar).Value = TextBox1.Text.ToString();
                    cmd.Connection = sqlConn;
                    sqlConn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                           
                            Label7.Text = "Email: " + (string)reader[0];
                            Label6.Text = (string)reader[2] + (string)reader[3];
                            Label8.Text = "Date of Birth: " + (string)reader[4];
                            Label9.Text = "Gender: " + (string)reader[5];
                            Label10.Text = "Commute: " + (string)reader[6];
                        }
                        else
                        {
                            Label6.Text = "No Search Found";
                        }
                    }
                    
                }
            }
            
        }
    }
}