﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.ComponentModel;
using System.Drawing;

namespace _1WeekAppliedProject
{
    public partial class Welcome : System.Web.UI.Page
    {
        string con = "Data Source=dixithg\\dixithsql;Initial Catalog=week1AP;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            string Email = Session["EmailS"].ToString();
            Label2.Text = Email;
            string firstname = Session["FirstNames"].ToString();
            string Lname = Session["LastNames"].ToString();
            Label1.Text = firstname + Lname;
            string Age = Session["AgeS"].ToString();
            Label3.Text = Age;
            string gender = Session["GenderS"].ToString();
            Label4.Text = gender;
            string Commute = Session["CommuteS"].ToString();
            Label5.Text = Commute;
            /***************************************/
            if (Image1.ImageUrl== "~/imgs/icon.jpg")
            {
                SqlDataAdapter myAdapter1 = new SqlDataAdapter("Select Imgid FROM Img2 WHERE email_id ='"+Label2.Text.ToString()+"'", con);
                DataTable dt = new DataTable();
                myAdapter1.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    // Get the byte array from image file
                    byte[] imgBytes = (byte[])row["Imgid"];

                    // If you want convert to a bitmap file
                    TypeConverter tc = TypeDescriptor.GetConverter(typeof(Bitmap));
                    Bitmap MyBitmap = (Bitmap)tc.ConvertFrom(imgBytes);

                    string imgString = Convert.ToBase64String(imgBytes);
                    //Set the source with data:image/bmp
                    Image1.ImageUrl = "data:image/jpeg;base64," + imgString;

                }
            }
            

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlConn = new SqlConnection(con))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"SELECT Email, Password, Fname, Lname, Age, Gender, Commute FROM Reg1 WHERE Fname = @idParam";
                    cmd.Parameters.Add("@idParam", SqlDbType.VarChar).Value = TextBox1.Text.ToString();
                    cmd.Connection = sqlConn;
                    sqlConn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                           
                            Label7.Text = "Email: " + (string)reader[0];
                            Label6.Text = (string)reader[2] + (string)reader[3];
                            Label8.Text = "Date of Birth: " + (string)reader[4];
                            Label9.Text = "Gender: " + (string)reader[5];
                            Label10.Text = "Commute: " + (string)reader[6];
                        }
                        else
                        {
                            Label6.Text = "No Search Found";
                        }
                    }
                    
                }
            }
            
        }
        
        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(con);
            //FileUpload img = (FileUpload)imgUpload;
                Byte[] imgByte = null;
            if (Image1.ImageUrl==null)
            {
                if (FileUpload1.HasFile && FileUpload1.PostedFile != null)
                {
                    //To create a PostedFile
                    HttpPostedFile File = FileUpload1.PostedFile;
                    //Create byte Array with file len
                    imgByte = new Byte[File.ContentLength];
                    //force the control to load data in array
                    File.InputStream.Read(imgByte, 0, File.ContentLength);
                }
                // Insert the employee name and image into db
                // string conn = ConfigurationManager.ConnectionStrings["EmployeeConnString"].ConnectionString;
                // connection = new SqlConnection(conn);

                connection.Open();
                string sql = "INSERT INTO Img2(email_id,Imgid) VALUES(@enm,@eimg) SELECT @@IDENTITY";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@enm", Label2.Text.ToString());
                cmd.Parameters.AddWithValue("@eimg", imgByte);
                int id = Convert.ToInt32(cmd.ExecuteNonQuery());
            }
            if (Image1.ImageUrl!=null)
            {
                
                if (FileUpload1.HasFile && FileUpload1.PostedFile != null)
                {
                    //To create a PostedFile
                    HttpPostedFile File = FileUpload1.PostedFile;
                    //Create byte Array with file len
                    imgByte = new Byte[File.ContentLength];
                    //force the control to load data in array
                    File.InputStream.Read(imgByte, 0, File.ContentLength);
                }
                // Insert the employee name and image into db
                // string conn = ConfigurationManager.ConnectionStrings["EmployeeConnString"].ConnectionString;
                // connection = new SqlConnection(conn);

                connection.Open();
                string sql = "INSERT INTO Img2(email_id,Imgid) VALUES(@email,@eimg) SELECT @@IDENTITY";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("@email", Label2.Text.ToString());
                cmd.Parameters.AddWithValue("@eimg", imgByte);
                int id = Convert.ToInt32(cmd.ExecuteNonQuery());
                
               
            }
                
               // Label5.Text = String.Format("Employee ID is {0}", id);
            /**************************************************************/

            SqlDataAdapter myAdapter1 = new SqlDataAdapter("Select Imgid FROM Img2 WHERE email_id = '"+Label2.Text.ToString()+"'",con);
            DataTable dt = new DataTable();
            myAdapter1.Fill(dt);

            foreach (DataRow row in dt.Rows)
            {
                // Get the byte array from image file
                byte[] imgBytes = (byte[])row["Imgid"];

                // If you want convert to a bitmap file
                TypeConverter tc = TypeDescriptor.GetConverter(typeof(Bitmap));
                Bitmap MyBitmap = (Bitmap)tc.ConvertFrom(imgBytes);

                string imgString = Convert.ToBase64String(imgBytes);
                //Set the source with data:image/bmp
                Image1.ImageUrl = "data:image/jpeg;base64," + imgString;

            }
        }
    }
}